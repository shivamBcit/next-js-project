/** @type {import('next').NextConfig} */
// next.config.js

module.exports = {
  webpack: (config) => {
    // Use the ignore-loader for .node files
    config.module.rules.push({
      test: /\.node$/,
      use: "ignore-loader",
    });

    return config;
  },

  env: {
    themeColors: {
      primary: '#FF5733', // i didnot use this color to any element

      secondary: '#D73C84',
      primaryBackgroundColor: "#FFF",

      footerBg: "#950E4D",

      animationBg: "#F8F7F7",
      textColor: "#D73C84",
      secondarytextColor: "#fff",

      lablingo : "#950E4D",

      smallText: "#232036"

      // Add more theme colors as needed
    },
    logoUrl: "/2tadawi.uae-png.svg", // dont need to pass public here,
    bgUrl: "/backgorund.png",
  },


  

};



