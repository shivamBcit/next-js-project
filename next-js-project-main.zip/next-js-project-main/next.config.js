/** @type {import('next').NextConfig} */
// next.config.js

module.exports = {
  webpack: (config) => {
    // Use the ignore-loader for .node files
    config.module.rules.push({
      test: /\.node$/,
      use: "ignore-loader",
    });

    return config;
  },

  env: {
    themeColors: {
      primary: '#FF5733', // i didnot use this color to any element

      secondary: 'linear-gradient(90deg, #777076 2.04%, #829A9A 93.7%)',

      primaryBackgroundColor: "linear-gradient(181deg, #252933 49.82%, #617C7C 98.79%)",


      footerBg: "#464E55",

      animationBg: "#262A34",
      textColor: "#829A9A",
      secondarytextColor: "#fff",

      // Add more theme colors as needed
    },
    logoUrl: "/tadawi.uae-png.svg", // dont need to pass public here,
    bgUrl: "/backgorund.png",
  },


  

};



